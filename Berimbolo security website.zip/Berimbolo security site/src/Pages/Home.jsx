import React from "react";
import lo from "../assets/re.png";

export default function Home() {
  return (
    <>
      <div className="hero">
        <div className="container c1">
          <h1>
            Protect your home and business with the latest in security
            technology
          </h1>
          <button
            className="btn btn-dark"
            data-bs-toggle="modal"
            data-bs-target="#quoteModal"
          >
            Get a Free Quote
          </button>
        </div>
      </div>

      <section className="services py-5">
        <div className="container">
          <h2 className="text-center mb-4">Our Services</h2>
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-2 g-4">
            <div className="col">
              <div className="card p-4">
                <h5>Home Security Systems</h5>
                <p>
                  Protect your home with state-of-the-art alarm systems,
                  surveillance cameras, and 24/7 monitoring.
                </p>
                <button
                  className="btn  btn-dark"
                  data-bs-toggle="modal"
                  data-bs-target="#homeSecurityModal"
                >
                  Learn more
                </button>
              </div>
            </div>
            <div className="col">
              <div className="card p-4">
                <h5>Small Business Security</h5>
                <p>
                  Secure your business with tailored access control systems and
                  robust monitoring solutions.
                </p>
                <button
                  className="btn  btn-dark"
                  data-bs-toggle="modal"
                  data-bs-target="#businessSecurityModal"
                >
                  Learn more
                </button>
              </div>
            </div>
            <div className="col">
              <div className="card p-4">
                <h5>Installation & Maintenance</h5>
                <p>
                  Professional installation of security systems and ongoing
                  maintenance to ensure peak performance.
                </p>
                <button
                  className="btn  btn-dark"
                  data-bs-toggle="modal"
                  data-bs-target="#installationModal"
                >
                  Learn more
                </button>
              </div>
            </div>
            <div className="col">
              <div className="card p-4">
                <h5>Custom Security Solutions</h5>
                <p>
                  Custom-tailored security systems to meet your unique
                  requirements.
                </p>
                <button
                  className="btn  btn-dark"
                  data-bs-toggle="modal"
                  data-bs-target="#customSecurityModal"
                >
                  Learn more
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="reviews py-5 bg-dark">
        <div className="container text-center">
          <h2>Reviews</h2>
          <p className="mt-3 text-light">
            <img src={lo} alt="Reviews" width={350} />
          </p>
        </div>
      </section>

      <section className="about py-5">
        <div className="container">
          <h2 className="text-center">About us</h2>
          <p className="mt-4 text-center">
            Berimbolo Security is committed to providing top-notch security
            solutions for homes and businesses. With years of experience, we
            ensure peace of mind with our reliable services and cutting-edge
            products.
          </p>
        </div>
      </section>

      {/* Bootstrap Modals */}
      {/* Quote Modal */}
      <div
        className="modal fade text-light"
        id="quoteModal"
        tabIndex="-1"
        aria-labelledby="quoteModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="quoteModalLabel">
                Get a Free Quote 
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              get a free quote for our services soon.
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Home Security Modal */}
      <div
        className="modal fade text-light"
        id="homeSecurityModal"
        tabIndex="-1"
        aria-labelledby="homeSecurityModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="homeSecurityModalLabel">
                Home Security Systems
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              Our home security systems include alarm systems, surveillance
              cameras, and 24/7 monitoring to keep your home safe.
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Business Security Modal */}
      <div
        className="modal fade text-light"
        id="businessSecurityModal"
        tabIndex="-1"
        aria-labelledby="businessSecurityModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="businessSecurityModalLabel">
                Small Business Security
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              Secure your business with custom access control and robust
              monitoring systems.
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Installation Modal */}
      <div
        className="modal fade text-light"
        id="installationModal"
        tabIndex="-1"
        aria-labelledby="installationModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="installationModalLabel">
                Installation & Maintenance
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              We offer professional installation and maintenance services to
              keep your security systems running at their best.
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Security Modal */}
      <div
        className="modal fade text-light"
        id="customSecurityModal"
        tabIndex="-1"
        aria-labelledby="customSecurityModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="customSecurityModalLabel">
                Custom Security Solutions
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              We design and implement security systems tailored to your specific
              needs.
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
