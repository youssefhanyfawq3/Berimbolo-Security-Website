import React from 'react';
import './a.css';
import ProductCard from './ProductCard';
import s1 from '../assets/s1.webp';
import s2 from '../assets/s2.jpg';
import s3 from '../assets/s3.webp';
import s4 from '../assets/s4.webp';
import s5 from '../assets/s5.jpg';
function Products() {
  const products = [
    {
      name: "HD Indoor Security Camera",
      description: "High-resolution indoor camera with night vision and motion detection.",
      price: "$129.99",
      image: s1,
    },
    {
      name: "Smart Home Alarm System",
      description: "Complete alarm system with door, window sensors, and a control panel.",
      price: "$49.99",
      image: s2,
    },
    {
      name: "Biometric Door Lock",
      description: "Secure your home or office with advanced fingerprint recognition.",
      price: "$219.99",
      image: s3,
    },
    {
      name: "4-Camera Outdoor Surveillance Kit",
      description: "Durable outdoor cameras with weatherproof design and remote monitoring.",
      price: "$299.99",
      image: s4,
    },
    {
      name: "Wireless Motion Detector",
      description: "Detect movement in your home or business with this compact device.",
      price: "$399.99",
      image: s5,
    },{
      name: "Smart Video Doorbell",
      description: "Get real-time video and two-way audio with this smart doorbell.",
      price: "$199.99",
      image: s4,
    },
  ];

  return (
    <div className="App">
      
      <main>
        <h2 className='text-light'>Our Products</h2>
        <div className="product-grid">
          {products.map((product, index) => (
            <ProductCard key={index} product={product} />
          ))}
        </div>
      </main>
      <footer>
        <p>Berimbolo Security © copy rights 2024</p>
      </footer>
    </div>
  );
}

export default Products;
