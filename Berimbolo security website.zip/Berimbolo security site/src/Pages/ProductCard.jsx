import React,{useState}from 'react';import './ProductCard.css';function ProductCard({product}){const[showModal,setShowModal]=useState(!1);const handleShowModal=()=>{setShowModal(!0)};const handleCloseModal=()=>{setShowModal(!1)};return(<div className="product-card text-light"><img src={product.image}alt={product.name}className="product-image"/><h3>{product.name}</h3><p>{product.description}</p><p className="price">{product.price}</p><button className="details-button" onClick={handleShowModal}>details</button>{}
  {showModal&&(<div
  className="modal fade show"
  style={{display:'block',backgroundColor:'rgba(0, 0, 0, 0.5)'}}
  tabIndex="-1"
  role="dialog"><div className="modal-dialog" role="document"><div className="modal-content"><div className="modal-header"><h5 className="modal-title">{product.name}</h5></div><div className="modal-body"><p>{product.description}</p><p><strong>Price:</strong>{product.price}</p><img
  src={product.image}
  alt={product.name}
  style={{width:'100%',borderRadius:'10px'}}/></div><div className="modal-footer"><button
  type="button"
  className="btn btn-secondary"
  onClick={handleCloseModal}>Close</button></div></div></div></div>)}</div>)}
  export default ProductCard